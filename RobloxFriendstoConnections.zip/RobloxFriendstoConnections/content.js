function replaceText(node) {
  if (node.nodeType === 3) {
    node.textContent = node.textContent
      .replace(/\bConnections\b/g, 'Friends')
      .replace(/\bConnect\b/g, 'Requests')
      .replace(/\bConnection\b/g, 'Friend');
  } else {
    for (let child of node.childNodes) {
      replaceText(child);
    }
  }
}

const observer = new MutationObserver((mutations) => {
  for (let mutation of mutations) {
    mutation.addedNodes.forEach(replaceText);
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Initial sweep
replaceText(document.body);
